from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from scrapy import signals
from scrapy.xlib.pydispatch import dispatcher

from ..items import GithubemailsItem
from itertools import zip_longest

import json
import os

API_KEY = ''

API_URL = "http://api.scraperapi.com/?api_key=%s&url=" % API_KEY

class GithubEmailsSpider(CrawlSpider):

    name = "githubemails"

    start_links = []
    end =[]
    error = []

    error_flag = 0

    usernames = []

    url = "https://api.github.com/users/swap_username/events/public"

    def __init__(self, new=None,error=None, *args, **kwargs):                    
        super(GithubEmailsSpider, self).__init__(*args, **kwargs)   
        
        dispatcher.connect(self.spider_closed, signals.spider_closed)

        if new == "yes":

            files_name = os.listdir("/home/hammadrauf/Desktop/done/githubemails/input")

            with open("start.txt","w") as s:

                for name in files_name:
                    try:
                        with open(f'/home/hammadrauf/Desktop/done/githubemails/input/{name}') as f:
                            data = json.load(f)

                            for info in data:

                                for username in info["info"]:  
                                    
                                    self.start_links.append(username["login"])
                                                                
                                    s.writelines(username["login"]+"\n")                      
                    except:

                        with open(f'/home/hammadrauf/Desktop/done/githubemails/input/{name}','a') as filee:
                            filee.write(']')

                        with open(f'/home/hammadrauf/Desktop/done/githubemails/input/{name}') as f:
                            data = json.load(f)

                            for info in data:

                                for username in info["info"]:

                                    self.start_links.append(username["login"])
                                                                
                                    s.writelines(username["login"]+"\n")  


        if  new == "error":
            self.error_flag = 1
            pass
                    

    def spider_closed(self,spider):
        print(self.end)
        print(self.error)
        print(self.start_links)

        with open("start.txt","w") as s:

            for names in self.start_links:

                if not names in self.end and not names in self.error:
                    s.writelines(names+"\n")
        
        with open("error.txt","w") as s:

            for names in self.error:

                s.writelines(names + "\n")

    def start_requests(self):


        if self.error_flag:

            with open(f'error.txt') as f:

                for info in f.readlines():

                        if info:
                            
                            info = info.replace("\n","")
                            temp = self.url
                            temp = temp.replace("swap_username",str(info))  

                            yield Request(url = API_URL+temp,meta={"username":info}, callback = self.parse)
        else:

            with open(f'start.txt') as f:

                for info in f.readlines():

                        if info:
                            
                            info = info.replace("\n","")
                            temp = self.url
                            temp = temp.replace("swap_username",str(info)) 
                            
                            yield Request(url = API_URL+temp,meta={"username":info}, callback = self.parse,errback=self.errback)

    def errback(self, response):

        temp = response.request.url
        temp = temp.split("users/")[1]
        temp = temp.split("/events")[0]

        self.error.append(temp)


    def parse(self, response):

        products = GithubemailsItem()

        products["username"] = response.meta["username"].replace("\n","")
            
        if response.status == 200:         

            products["author"] = []

            emails = []

            json_text = response.text

            if json_text:

                json_obj = json.loads(json_text)

                for obj in json_obj:

                    try:

                        for email in obj["payload"]["commits"]:

                            save_email = email["author"]["email"]
                            save_name = email["author"]["name"]

                            info = {"email":save_email,
                                    "name":save_name
                            }                            

                            if len(emails) == 0:
                                emails.append(save_email)
                                products["author"].append(info)
                            else:

                                if not save_email in emails:
                                    emails.append(save_email)
                                    products["author"].append(info)
                                                        
                    except:
                        pass
    
                self.end.append(products["username"])
                yield products

