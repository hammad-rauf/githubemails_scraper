scrapy crawl githubemails -o data.json -a new=yes

this script will read all usernames from input directory files

then i am tracking all error and 200 https response

all username which got error while requesting are inside error.txt

all usernames which were scraped 200 https response and error usernames are not inside start.txt

if you run the script again with     -a new=no           the script will start from usernames which was left last time not restarting from id 1 again

 
scrapy crawl githubemails -o data.json -a new=error

this will only read error.txt file not start.txt not input directory


scrapy crawl githubemails -o data.json -a new=no

this will only read start.txt 
